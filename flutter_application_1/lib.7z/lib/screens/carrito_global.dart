library carrito_global;

List<Map<String, dynamic>> carrito = [];
